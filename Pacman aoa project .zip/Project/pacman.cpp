/*
 ============================================================
  PACMAN GAME - C++ Console Implementation
  Algorithm Used: BFS (Breadth-First Search) for Ghost AI
  Course: Analysis of Algorithms | Spring 2026
  Instructor: Mr. Muhammad Usman Sharif
 ============================================================
*/

#include <iostream>
#include <vector>
#include <queue>
#include <conio.h>      // For _kbhit() and _getch() on Windows
#include <windows.h>    // For Sleep() and console cursor
#include <ctime>

using namespace std;

// ============================================================
// CONSTANTS
// ============================================================
const int ROWS = 10;
const int COLS = 20;

// Map symbols
const char WALL    = '#';
const char DOT     = '.';
const char EMPTY   = ' ';
const char PACMAN  = 'C';
const char GHOST   = 'G';
const char POWER   = 'O';  // Power pellet

// Directions
const int DR[] = {-1, 1, 0, 0}; // Up, Down, Left, Right
const int DC[] = {0, 0, -1, 1};

// ============================================================
// GLOBAL GAME MAP (10 rows x 20 cols)
// ============================================================
char gameMap[ROWS][COLS] = {
    "####################",
    "#........#.........#",
    "#.##.###.#.###.##..#",
    "#O..............  O#",
    "#.##.#.#####.#.##..#",
    "#....#...#...#.....#",
    "#.####.#####.####..#",
    "#......#...#.......#",
    "#.##.......#...##..#",
    "####################"
};

// ============================================================
// POSITION STRUCTURE
// ============================================================
struct Position {
    int row, col;
};

// ============================================================
// GAME STATE VARIABLES
// ============================================================
Position pacman;
Position ghost;
int score = 0;
int lives = 3;
bool gameOver = false;
bool won = false;

// ============================================================
// FUNCTION: Hide console cursor (for cleaner display)
// ============================================================
void hideCursor() {
    HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO info;
    info.dwSize = 100;
    info.bVisible = FALSE;
    SetConsoleCursorInfo(consoleHandle, &info);
}

// ============================================================
// FUNCTION: Move cursor to top-left for redrawing
// ============================================================
void gotoxy(int x, int y) {
    COORD coord;
    coord.X = x;
    coord.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

// ============================================================
// FUNCTION: Initialize starting positions
// ============================================================
void initGame() {
    // Place Pacman at row 1, col 1
    pacman = {1, 1};
    // Place Ghost at row 1, col 18
    ghost  = {1, 18};
    score  = 0;
    lives  = 3;
    gameOver = false;
    won = false;

    // Restore dots in map (reset)
    gameMap[1][1]  = DOT;
    gameMap[1][18] = DOT;
}

// ============================================================
// FUNCTION: Count remaining dots
// ============================================================
int countDots() {
    int count = 0;
    for (int r = 0; r < ROWS; r++)
        for (int c = 0; c < COLS; c++)
            if (gameMap[r][c] == DOT || gameMap[r][c] == POWER)
                count++;
    return count;
}

// ============================================================
// FUNCTION: Draw the game map
// ============================================================
void drawMap() {
    gotoxy(0, 0);

    // Draw top info bar
    cout << "  PACMAN GAME  |  Score: " << score
         << "  |  Lives: " << lives
         << "  |  Dots Left: " << countDots() << "   " << endl;
    cout << endl;

    // Draw map with Pacman and Ghost
    for (int r = 0; r < ROWS; r++) {
        cout << "  ";
        for (int c = 0; c < COLS; c++) {
            if (r == pacman.row && c == pacman.col)
                cout << PACMAN;
            else if (r == ghost.row && c == ghost.col)
                cout << GHOST;
            else
                cout << gameMap[r][c];
        }
        cout << endl;
    }

    cout << endl;
    cout << "  Controls: W=Up  S=Down  A=Left  D=Right  Q=Quit" << endl;
}

// ============================================================
// FUNCTION: Move Pacman based on key input
// ============================================================
void movePacman(char key) {
    int newRow = pacman.row;
    int newCol = pacman.col;

    if (key == 'w' || key == 'W') newRow--;
    else if (key == 's' || key == 'S') newRow++;
    else if (key == 'a' || key == 'A') newCol--;
    else if (key == 'd' || key == 'D') newCol++;
    else return;

    // Check wall collision
    if (newRow < 0 || newRow >= ROWS || newCol < 0 || newCol >= COLS)
        return;
    if (gameMap[newRow][newCol] == WALL)
        return;

    // Move Pacman
    pacman.row = newRow;
    pacman.col = newCol;

    // Eat dot
    if (gameMap[pacman.row][pacman.col] == DOT) {
        score += 10;
        gameMap[pacman.row][pacman.col] = EMPTY;
    }
    // Eat power pellet
    else if (gameMap[pacman.row][pacman.col] == POWER) {
        score += 50;
        gameMap[pacman.row][pacman.col] = EMPTY;
    }
}

// ============================================================
// ALGORITHM: BFS - Ghost finds shortest path to Pacman
// This is the CORE algorithm of the project.
//
// BFS explores all neighbors level by level.
// It guarantees the SHORTEST path from ghost to Pacman.
// Time Complexity: O(V + E) = O(ROWS * COLS)
// ============================================================
Position bfsNextMove(Position start, Position target) {
    // visited array
    bool visited[ROWS][COLS] = {};
    // parent array to trace back path
    Position parent[ROWS][COLS];

    // Initialize parent to invalid
    for (int r = 0; r < ROWS; r++)
        for (int c = 0; c < COLS; c++)
            parent[r][c] = {-1, -1};

    queue<Position> q;
    q.push(start);
    visited[start.row][start.col] = true;

    bool found = false;

    // BFS Loop
    while (!q.empty() && !found) {
        Position curr = q.front();
        q.pop();

        // Explore 4 directions
        for (int d = 0; d < 4; d++) {
            int nr = curr.row + DR[d];
            int nc = curr.col + DC[d];

            // Boundary & wall check
            if (nr < 0 || nr >= ROWS || nc < 0 || nc >= COLS) continue;
            if (gameMap[nr][nc] == WALL) continue;
            if (visited[nr][nc]) continue;

            visited[nr][nc] = true;
            parent[nr][nc] = curr;
            q.push({nr, nc});

            // Found Pacman
            if (nr == target.row && nc == target.col) {
                found = true;
                break;
            }
        }
    }

    // If no path found, stay
    if (!found) return start;

    // Trace back path from target to find first step
    Position step = target;
    while (!(parent[step.row][step.col].row == start.row &&
             parent[step.row][step.col].col == start.col)) {
        step = parent[step.row][step.col];
        if (step.row == -1) return start; // safety
    }

    return step; // This is the next move for the ghost
}

// ============================================================
// FUNCTION: Move Ghost using BFS
// ============================================================
void moveGhost() {
    Position next = bfsNextMove(ghost, pacman);
    ghost = next;
}

// ============================================================
// FUNCTION: Check if ghost caught Pacman
// ============================================================
void checkCollision() {
    if (ghost.row == pacman.row && ghost.col == pacman.col) {
        lives--;
        if (lives <= 0) {
            gameOver = true;
        } else {
            // Reset positions
            pacman = {1, 1};
            ghost  = {1, 18};
        }
    }
}

// ============================================================
// FUNCTION: Check win condition
// ============================================================
void checkWin() {
    if (countDots() == 0) {
        won = true;
        gameOver = true;
    }
}

// ============================================================
// MAIN FUNCTION
// ============================================================
int main() {
    hideCursor();
    initGame();
    system("cls");

    cout << "\n\n";
    cout << "  ************************************\n";
    cout << "  *       PACMAN - BFS GHOST AI      *\n";
    cout << "  *  Press any key to start...       *\n";
    cout << "  ************************************\n";
    _getch();

    system("cls");

    // Ghost moves every 3 Pacman moves
    int ghostTimer = 0;

    while (!gameOver) {
        drawMap();

        // Read key input (non-blocking)
        if (_kbhit()) {
            char key = _getch();
            if (key == 'q' || key == 'Q') break;
            movePacman(key);
            ghostTimer++;

            // Ghost moves every 3 turns (makes game fair)
            if (ghostTimer >= 3) {
                moveGhost();
                ghostTimer = 0;
            }

            checkCollision();
            checkWin();
        }

        Sleep(50); // Small delay
    }

    // Final screen
    system("cls");
    cout << "\n\n";
    if (won) {
        cout << "  *** YOU WIN! ***\n";
        cout << "  Final Score: " << score << "\n";
    } else {
        cout << "  *** GAME OVER ***\n";
        cout << "  Final Score: " << score << "\n";
    }
    cout << "\n  Press any key to exit...\n";
    _getch();

    return 0;
}

/*
 ============================================================
  HOW TO COMPILE:
  g++ pacman.cpp -o pacman.exe
  Run: pacman.exe

  NOTE: This uses Windows-specific headers (conio.h, windows.h)
  Tested on: Windows 10/11 with MinGW g++ compiler
 ============================================================
*/
